package gridworld;

import java.util.ArrayList;

import info.gridworld.actor.Actor;
import info.gridworld.actor.Critter;
import info.gridworld.grid.Grid;
import info.gridworld.grid.Location;

public class Seedot extends Actor {
	/**
	 * Set a low percentage chance that a seedot will turn into a sudowoodo
	 */
	@Override
	public void act() {
		germinate();
	}

	private void germinate() {
		Location myLoc = this.getLocation();
		int turn = (int) (Math.random() * 500);
		Grid<Actor> grid = getGrid();

		if (turn == 0) {
			this.removeSelfFromGrid();
			new Sudowoodo().putSelfInGrid(grid, myLoc);
		}
	}
}
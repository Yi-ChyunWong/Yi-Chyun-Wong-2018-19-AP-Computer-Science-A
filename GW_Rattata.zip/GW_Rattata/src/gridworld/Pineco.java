package gridworld;

import info.gridworld.actor.Actor;

public class Pineco extends Actor
{
	@Override
	public void act()
	{
		// DO NOTHING
	}
}
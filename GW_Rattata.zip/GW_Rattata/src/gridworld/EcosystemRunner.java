	package gridworld;

import info.gridworld.actor.ActorWorld;

public class EcosystemRunner
{
	/**
	 * TODO: Complete the Rattata, Seedot, and Sudowoodo classes!
	 */
	public static void main(String[] args)
	{
		ActorWorld world = new ActorWorld();
		world.add(new Rattata());
		world.add(new Seedot());
		world.add(new Pineco());
		world.add(new Sudowoodo());
		world.show();
	}
}
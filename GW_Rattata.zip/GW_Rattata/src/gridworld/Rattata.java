package gridworld;

import java.util.ArrayList;

import info.gridworld.actor.Actor;
import info.gridworld.actor.Critter;
import info.gridworld.grid.Grid;
import info.gridworld.grid.Location;

public class Rattata extends Critter {

	private boolean hasNut = false;

	public Rattata() {
		setDirection(45 * (int) (Math.random() * 8));
	}

	@Override
	public ArrayList<Actor> getActors() {
		ArrayList<Actor> a = new ArrayList<Actor>();
		ArrayList<Location> locList = new ArrayList<Location>();
		Grid<Actor> grid = getGrid();
		Location myLoc = getLocation();

		Location locF = myLoc.getAdjacentLocation(getDirection());
		Location locLF = locF.getAdjacentLocation(getDirection()+270);
		Location locRF = locF.getAdjacentLocation(getDirection()+90);

		locList.add(locF);
		locList.add(locLF);
		locList.add(locRF);

		for (Location l : locList) {
			if (grid.isValid(l) && grid.get(l) != null)
				a.add(grid.get(l));
		}

		return a;
	}

	@Override
	public void processActors(ArrayList<Actor> actors) {
		for (Actor a : actors) {
			if (a instanceof Pineco) {
				this.hasNut = true;
				a.removeSelfFromGrid();
			}
		}

		if (!this.hasNut) {
			for (Actor a : actors) {
				if (a instanceof Sudowoodo) {
					if(this.getLocation() != null) {
						this.removeSelfFromGrid();
						((Sudowoodo) a).enterSudowoodo(this);
					}
				}
			}
		}
	}

	@Override
	public ArrayList<Location> getMoveLocations() {
		if (this.getLocation() != null)
			return super.getMoveLocations();
		return new ArrayList<Location>();
	}

	public void setHasNut(boolean hasNut) {
		this.hasNut = hasNut;
	}

	@Override	
	public void makeMove(Location loc) {
		if(loc == this.getLocation()) {
			this.setDirection(45 * (int) (Math.random() * 8));
			return;
		}
		if (this.getLocation() != null) {
			int crackNut = (int) (Math.random() * 2);
			int eatNut = (int) (Math.random() * 10);
			Grid<Actor> grid = getGrid();
			Location origLoc = this.getLocation();

			setDirection(origLoc.getDirectionToward(loc));
			super.moveTo(loc);

			if (this.hasNut) {
				if (crackNut == 1) {
					this.hasNut = false;
					if (eatNut == 0) {
						new Seedot().putSelfInGrid(grid, origLoc);
					}
				}
			}
		}
	}
}
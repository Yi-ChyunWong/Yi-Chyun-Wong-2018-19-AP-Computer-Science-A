package gridworld;

import java.util.ArrayList;

import info.gridworld.grid.Location;
import info.gridworld.actor.Actor;
import info.gridworld.grid.Grid;

public class Sudowoodo extends Actor {
	ArrayList<Rattata> rattatas = new ArrayList<Rattata>();

	/**
	 * If there is one or more rattatas in the sudowoodo, spit ONE out in a random
	 * direction. Make sure to set the direction of the rattata away from the
	 * sudowoodo. If there are no rattatas in the sudowoodo, set a low percentage
	 * chance that the sudowoodo will drop a nut in a random spot around the
	 * sudowoodo.
	 */
	@Override
	public void act() {
		ArrayList<Location> spawn = new ArrayList<Location>();
		Grid<Actor> grid = getGrid();
		Location spawned = null;

		for (int i = 0; i <= 315; i += 45) {
			Location loc = this.getLocation().getAdjacentLocation(i);
			if (grid.isValid(loc) && grid.get(loc) == null) {
				spawn.add(loc);
			}
		}
		
		if(spawn.size()>0) {
			spawned = spawn.get((int) (Math.random() * spawn.size()));
			if (rattatas.size() > 0) {
				Rattata rat = rattatas.remove((int) (Math.random() * rattatas.size()));
				rat.putSelfInGrid(grid, spawned);
				rat.setDirection(this.getLocation().getDirectionToward(rat.getLocation()));
			} else {
				if ((int) (Math.random() * 100) == 0)
					new Pineco().putSelfInGrid(grid, spawned);
			}
		}
	}

	public void enterSudowoodo(Rattata rattata) {
		rattatas.add(rattata);
	}
}
package apcsa;

import java.util.Scanner;

public class Main
{
	public static void main(String[] args)
	{
		Scanner scan = new Scanner(System.in);

		System.out.println("Type a secret message to encode:");
		String secretMessage = scan.nextLine().toUpperCase();

		String encodedMessage = EncodeDecode.encode(secretMessage);
		System.out.println(encodedMessage);

		String decodedMessage = EncodeDecode.decode(encodedMessage);
		if (decodedMessage.equals(secretMessage))
		{
			System.out.println("SUCCESS");
		} else
		{
			System.out.println("FAILURE");
		}

		scan.close();
	}
}
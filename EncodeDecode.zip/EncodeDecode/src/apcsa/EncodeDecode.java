package apcsa;

public class EncodeDecode
{
	/**
	 * Encodes the message by reversing it and replacing at least seven of the
	 * letters. For example, you could replace all 'A's with '@'s, and 'S's with
	 * '$'s, 'E's with '3's, etc... OR you could do something that is harder to
	 * read! Imagine that you're the Allies trying to encode your secret messages
	 * during WWII so that the Axis Powers don't know what you're up to.
	 */
	
	public static String encode(String msg)
	{
		String rtn = msg;
		rtn = reverse(rtn);
		
		for(int i = 0; i < rtn.length(); i++) {
			String seg = rtn.substring(i, i+1);
			seg = codeReferences(seg);
			String left = rtn.substring(0,i);
			String right = rtn.substring(i+1);
			rtn = left + seg + right;
		}
		
		return rtn;
	}

	/**
	 * Undoes the encoding.
	 */
	public static String decode(String msg)
	{
		msg = reverse(msg);
		String rtn = "";
		for(int i = 0; i < msg.length(); i++) {
			String seg = msg.substring(i, i+1);
			seg = decoding(seg);
			rtn += seg;
		}
		return rtn;
	}

	/**
	 * Reverses the message.
	 */
	private static String reverse(String msg)
	{
		String rtn = "";
		
		for(int i = msg.length()-1; i > -1; i--) {
			rtn += msg.substring(i, i+1);
		}
		
		return rtn;
	}
	
	private static String codeReferences(String msgSeg) {
		String rep;
		if(msgSeg.equals("A")) {
			rep = "@";
			return rep;
		} else if(msgSeg.equals("B")) {
			rep = "!";
			return rep;
		} else if(msgSeg.equals("C")) {
			rep = "$";
			return rep;
		} else if(msgSeg.equals("D")) {
			rep = "#";
			return rep;
		} else if(msgSeg.equals("E")) {
			rep = "^";
			return rep;
		} else if(msgSeg.equals("F")) {
			rep = "%";
			return rep;
		} else if(msgSeg.equals("G")) {
			rep = "*";
			return rep;
		} else if(msgSeg.equals("H")) {
			rep = "&";
			return rep;
		} else if(msgSeg.equals("I")) {
			rep = ")";
			return rep;
		} else if(msgSeg.equals("J")) {
			rep = "(";
			return rep;
		} else if(msgSeg.equals("K")) {
			rep = "=";
			return rep;
		} else if(msgSeg.equals("L")) {
			rep = "-";
			return rep;
		} else if(msgSeg.equals("M")) {
			rep = "+";
			return rep;
		} else if(msgSeg.equals("N")) {
			rep = "_";
			return rep;
		} else if(msgSeg.equals("O")) {
			rep = "]";
			return rep;
		} else if(msgSeg.equals("P")) {
			rep = "[";
			return rep;
		} else if(msgSeg.equals("Q")) {
			rep = "}";
			return rep;
		} else if(msgSeg.equals("R")) {
			rep = "{";
			return rep;
		} else if(msgSeg.equals("S")) {
			rep = "|";
			return rep;
		} else if(msgSeg.equals("T")) {
			rep = ";";
			return rep;
		} else if(msgSeg.equals("U")) {
			rep = ":";
			return rep;
		} else if(msgSeg.equals("V")) {
			rep = ".";
			return rep;
		} else if(msgSeg.equals("W")) {
			rep = ",";
			return rep;
		} else if(msgSeg.equals("X")) {
			rep = ">";
			return rep;
		} else if(msgSeg.equals("Y")) {
			rep = "<";
			return rep;
		} else if(msgSeg.equals("Z")) {
			rep = "/";
			return rep;
		} else {
			return msgSeg;
		}
	}
	
	private static String decoding(String msgSeg) {
		switch(msgSeg) {
		case "@":
			return "A";			
		case "!":
			return "B";			
		case "$":
			return "C";			
		case "#":
			return "D";			
		case "^":
			return "E";			
		case "%":
			return "F";			
		case "*":
			return "G";			
		case "&":
			return "H";				
		case ")":
			return "I";			
		case "(":
			return "J";			
		case "=":
			return "K";			
		case "-":
			return "L";			
		case "+":
			return "M";			
		case "_":
			return "N";			
		case "]":
			return "O";			
		case "[":
			return "P";			
		case "}":
			return "Q";			
		case "{":
			return "R";			
		case "|":
			return "S";			
		case ";":
			return "T";			
		case ":":
			return "U";			
		case ".":
			return "V";			
		case ",":
			return "W";
		case ">":
			return "X";
		case "<":
			return "Y";
		case "/":
			return "Z";
		default:
			return msgSeg;
		}
	}
}
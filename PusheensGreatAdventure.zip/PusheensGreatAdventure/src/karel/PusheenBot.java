package karel;

import java.awt.Color;

import kareltherobot.*;

public class PusheenBot extends TurnRightBot {

	public PusheenBot(int street, int avenue, Direction direction, int beepers, Color badge) {
		super(street, avenue, direction, beepers, badge);
	}

	public void faceRandomDirection() {
		for (int i = 0; i < (int) (Math.random() * 4) + 4; i++) {
			turnLeft();
		}
	}

	public void epicJourney() {
		waddleNorth();
		waddleEast();
		cookieTrail();
		foundKarel();
		waddle10Steps();
		turnToFrontIsClear();
		dilemma7();
		wallAfterRightTurn();
		waddleEastUndNorth();
		eatPizzaUndGoEast();
		lootTreasure();
		doVictoryDance();
	}

	private void waddleNorth() {
		faceDirNorth();
		while (frontIsClear()) {
			move();
		}
	}

	private void faceDirSouth() {
		while (!facingSouth()) {
			turnLeft();
		}
	}

	private void faceDirEast() {
		while (!facingEast()) {
			turnLeft();
		}
	}

	private void faceDirNorth() {
		while (!facingNorth()) {
			turnLeft();
		}
	}

	private void faceDirWest() {
		while (!facingWest()) {
			turnLeft();
		}
	}

	private void waddleEast() {
		turnRight();
		while (frontIsClear()) {
			move();
		}
	}

	private void cookieTrail() {
		while (!nextToARobot()) {
			if (nextToABeeper()) {
				faceDirEast();
				eatAllCookies();
			} else {
				move();
			}
		}
	}

	private void eatAllCookies() {
		if (nextToABeeper()) {
			pickBeeper();
			turnLeft();
			eatAllCookies();
		}
	}

	private void foundKarel() {
		if (facingNorth()) {
			faceDirSouth();
		} else if (facingWest()) {
			faceDirNorth();
		} else {
			faceDirEast();
		}
	}

	private void waddle10Steps() {
		for (short i = 0; i < 10; i++) {
			move();
		}
	}

	private void turnToFrontIsClear() {
		while (!frontIsClear()) {
			turnLeft();
		}
	}

	private void dilemma7() {
		turnLeft();
		if (frontIsClear()) {
			turnRight();
			while (frontIsClear()) {
				move();
			}
		} else {
			turnRight();
			waddle10Steps();
		}
	}

	private void wallAfterRightTurn() {
		turnRight();
		while (frontIsClear()) {
			move();
		}
		faceDirEast();
	}

	private void waddleEastUndNorth() {
		if (!nextToABeeper()) {
			move();
			waddleEastUndNorth();
			move();
		} else {
			faceDirNorth();
		}
	}

	private void eatPizzaUndGoEast() {
		if (nextToABeeper()) {
			pickBeeper();
			eatPizzaUndGoEast();
			move();
		} else {
			faceDirEast();
		}
	}

	private void lootTreasure() {
		while (nextToABeeper()) {
			pickBeeper();
		}
	}

	private void doVictoryDance() {
		int i, j;
		for (j = 0; j < 10; j++) {
			for (i = 0; i < 4; i++) {
				turnLeft();
			}
		}
	}

}

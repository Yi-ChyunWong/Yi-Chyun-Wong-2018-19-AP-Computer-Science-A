package karel;

import java.awt.Color;

import kareltherobot.*;

public class TurnRightBot extends Robot{

	public TurnRightBot(int street, int avenue, Direction direction, int beepers, Color badge) {
		super(street, avenue, direction, beepers, badge);
		// TODO Auto-generated constructor stub
	}
	
	public void turnRight() {
		turnLeft();
		turnLeft();
		turnLeft();
	}

}

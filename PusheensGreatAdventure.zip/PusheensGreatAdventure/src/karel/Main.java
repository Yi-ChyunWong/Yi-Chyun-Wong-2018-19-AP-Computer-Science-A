package karel;

import java.awt.Color;

import kareltherobot.*;

public class Main implements Directions
{
	public static void main(String[] args)
	{
		World.setVisible(true);
		World.setStreetColor(Color.BLACK);
		World.setBeeperColor(Color.BLACK);
		World.setDelay(10);
		World.reset();
		World.readWorld("worlds", "adventure.kwld");

		// v v v DO NOT MODIFY v v v
		UrRobot karel = new UrRobot(14, 12, North, 0, Color.RED);
		karel.turnOff();
		PusheenBot pusheen = new PusheenBot(1, 1, North, 0, Color.GRAY);
		pusheen.faceRandomDirection();
		// ^ ^ ^ DO NOT MODIFY ^ ^ ^
		
		pusheen.epicJourney();

	}
}

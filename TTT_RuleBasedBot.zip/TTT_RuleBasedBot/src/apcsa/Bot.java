package apcsa;

import java.util.ArrayList;
import java.util.List;

public class Bot {
	private char botID;
	private char playerID;

	public char getID() {
		return botID;
	}

	public void setID(char botID) {
		this.botID = botID;
		if (botID == 'X') {
			this.playerID = 'O';
		} else {
			this.playerID = 'X';
		}
	}

	public Move doMove(char[][] board) {
		List<Move> validMoves = new ArrayList<Move>();
		for (int row = 0; row < 3; row++) {
			for (int col = 0; col < 3; col++) {
				if (board[row][col] == ' ') {
					validMoves.add(new Move(col, row));
				}
			}
		}

		Move move;
		
		if ((move = threeInARow(board, validMoves, botID)) != null) {
			return move;
		} else if ((move = threeInARow(board, validMoves, playerID)) != null) {
			return move;
		} else if (didTheOpponentPlaceTheirFirst2OnOppositeCorners(board, validMoves)) {
			return whenTheOpponentPlacedTheirFirst2OnOppositeCorners(board);
		} else if (didOpponentPlaceTheirFirstTwoOnOppositeSides(board, validMoves)) {
			return placeInCorner();
		} else if (didOpponentStartFromTheMiddle(board, validMoves)) {
			return placeInCorner();
		} else if(didOpponentPlaceTheirFirstTwoOnAdjacentSides(board, validMoves)) {
			return ifOpponentPlacedTheirFirstTwoOnAdjacentSides(board);
		} else if (didTheOpponentPlaceTheirFirstOneOnTheSidesWhenTheBotStarts(board, validMoves)) {
			return whenBotStartsAndTheOpponentPlacedTheirFirstOneOnTheSides(board);
		} else if (board[1][1] == ' ') {
			return new Move(1, 1);
		}
		
		move = validMoves.get((int) (Math.random() * validMoves.size()));
		return move;
	}

	private Move threeInARow(char[][] board, List<Move> moves, char ID) {
		for (Move move : moves) {
			if (horizontalThreeInARow(board, move, ID)) {
				return move;
			}

			if (verticalThreeInARow(board, move, ID)) {
				return move;
			}

			if ((move.getX() + move.getY()) % 2 == 0) { // center or corner
				if (diagonalThreeInARow(board, move, ID)) {
					return move;
				}
			}
		}
		return null;
	}
	
	private boolean horizontalThreeInARow(char[][] board, Move move, char ID) {
		boolean threeInARow = false;
		board[move.getY()][move.getX()] = ID;

		if (board[move.getY()][0] == board[move.getY()][1] && board[move.getY()][1] == board[move.getY()][2]) {
			threeInARow = true;
		}

		board[move.getY()][move.getX()] = ' ';
		return threeInARow;
	}


	private boolean verticalThreeInARow(char[][] board, Move move, char ID) {
		boolean threeInARow = false;
		board[move.getY()][move.getX()] = ID;

		if (board[0][move.getX()] == board[1][move.getX()] && board[1][move.getX()] == board[2][move.getX()]) {
			threeInARow = true;
		}

		board[move.getY()][move.getX()] = ' ';
		return threeInARow;
	}

	private boolean diagonalThreeInARow(char[][] board, Move move, char ID) {
		boolean threeInARow = false;
		board[move.getY()][move.getX()] = ID;

		if (move.getY() != move.getX() || (move.getY() == 1 && move.getX() == 1)) {
			if (board[0][2] == board[1][1] && board[1][1] == board[2][0]) {
				threeInARow = true;
			}
		} 

	if (move.getY() == move.getX()) {
			if (board[0][0] == board[1][1] && board[1][1] == board[2][2]) {
				threeInARow = true;
			}
		}

		board[move.getY()][move.getX()] = ' ';
		return threeInARow;
	}

	
	private boolean didTheOpponentPlaceTheirFirst2OnOppositeCorners(char[][]board, List<Move> moves) {
		if(moves.size() == 6) {
			if((board[0][0] == playerID && board[2][2] == playerID) || (board[0][2] == playerID && board[2][0] == playerID)) {
				return true;
			}
		}
		return false;
	}
	
	private Move whenTheOpponentPlacedTheirFirst2OnOppositeCorners(char[][]board) {
		if(board[0][0] == playerID && board[2][2] == playerID)	{
			Move rtnMove = new Move(0,1);
			return rtnMove;
		} else {
			Move rtnMove = new Move(2,1);
			return rtnMove;
		}
	}
	
	private boolean didTheOpponentPlaceTheirFirstOneOnTheSidesWhenTheBotStarts(char[][]board, List<Move> moves) {
		if(moves.size() == 7 && board[1][1] == botID) {
			if(board[0][1] == playerID || board[1][0] == playerID || board[1][2] == playerID || board[2][1] == playerID) {
				return true;
			}
		}
		return false;
	}
	
	private Move whenBotStartsAndTheOpponentPlacedTheirFirstOneOnTheSides(char[][]board) {
		if(board[1][2] == playerID|| board[2][1] == playerID) {
			Move rtnMove = new Move(0,0);
			return rtnMove;
		} else {
			Move rtnMove = new Move(2,2);
			return rtnMove;
		}
	}
	
	private boolean didOpponentStartFromTheMiddle(char[][]board, List<Move> moves) {
		if(moves.size() == 8 && board[1][1] == playerID) {
			return true;
		}
		return false;
	}
	
	private Move placeInCorner() {
		Move rtnMove = new Move(0,0);
		return rtnMove;
	}
	
	private boolean didOpponentPlaceTheirFirstTwoOnOppositeSides(char[][]board, List<Move> moves) {
		if(moves.size() == 6) {
			if(board[0][1] == playerID && board[2][1] == playerID || board[1][0] == playerID && board[1][2] == playerID) {
				return true;
			}
		}
		return false;
	}
	
	private boolean didOpponentPlaceTheirFirstTwoOnAdjacentSides(char[][]board, List<Move> moves) {
		if(moves.size() == 6) {
			if((board[0][1] == playerID || board[2][1] == playerID) && (board[1][0] == playerID || board[1][2] == playerID)) {
				return true;
			}
		}
		return false;
	}
	
	private Move ifOpponentPlacedTheirFirstTwoOnAdjacentSides(char[][]board) {
		if(board[0][1] == playerID) {
			if(board[1][0] == playerID) {
				Move rtnMove = new Move(0,0);
				return rtnMove;
			} else {
				Move rtnMove = new Move(2,0);
				return rtnMove;
			}
		} else {
			if(board[1][0] == playerID) {
				Move rtnMove = new Move(0,2);
				return rtnMove;
			} else {
				Move rtnMove = new Move(2,2);
				return rtnMove;
			}
		}
	}

}
package apcsa;

public class Main
{

	public static void main(String[] args)
	{
		int[] testArr = {0,2,4,6,8};
		System.out.println(BinarySearch.binarySearchIterative(testArr, 5));
		System.out.println(BinarySearch.binarySearchRecursive(testArr, 5));
	}
}

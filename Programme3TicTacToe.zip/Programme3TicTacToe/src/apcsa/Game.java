package apcsa;

import java.awt.Point;
import java.util.Scanner;

public class Game {
	private char[][] board; //instance
	private char turn;
	private int  gameNumber;
	private static Scanner scan;
	
	public static void init() {
		scan = new Scanner(System.in);
	}
	
	public static void close() {
		scan.close();
	}
	
	public Game(int gameNumber) {
		this.gameNumber = gameNumber;
		this.board = new char [3][3];
		
		clearBoard();
	}
	
	public void gameLoop() {
		boolean gaming = true;
		while(gaming == true) {
			int count = 0;
			clearBoard();
			printBoard();
			while(!winCondition() && !tieCheck()) {
				count = (count+1)%2;
				if(count == 1) {
					this.turn = 'O';
				} else {
					this.turn = 'X';
				}
				Point move = inputForGenericSquareBoardGame(this.turn);
				this.board[move.x][move.y] = this.turn;
				printBoard();
			}
			
			if(tieCheck()) {
				System.out.println("It's a tie!");
			} else {
				if(this.turn == 'X') {
					System.out.println("Player 2 wins!");
				} else {
					System.out.println("Player 1 wins!");
				}
			}
			
			gaming = false;
			
			while(gaming == false) {
				System.out.println("Do you wanna play again?");
				
				String response = scan.next();
				scan.nextLine();
				
				if(response.toLowerCase().equals("yes")) {
					gaming = true;
				} else if (response.toLowerCase().equals("no")) {
					break;
				}
			}
		}
	}
	
	private Point inputForGenericSquareBoardGame(char turn)
	{
		boolean validNum = false;
		
		int x2 = 3;
		int y2 = 3;
		
		if(turn == 'O') {
			System.out.println("Player 1 make a move.");
		} else {
			System.out.println("Player 2 make a move.");
		}
		
		while(validNum == false) {
			
			if(scan.hasNextInt()) {
				x2 = scan.nextInt();
			}
			
			if(scan.hasNextInt()) {
				y2 = scan.nextInt();
			}
			
			if(x2>=0 && x2 <= 2 && y2>=0 && y2 <= 2 && this.board[x2][y2]==' ') {
				validNum = true;
			} else {
				System.out.println("Try again. Make a move");
			}
			this.scan.nextLine();
		}
		return new Point(x2,y2);
	}
		
	public void printBoard(){
		System.out.println(" " + this.board[0][0] + " | " + this.board[0][1] + " | " + this.board[0][2] + " ");
		System.out.println("---+---+---");
		System.out.println(" " + this.board[1][0] + " | " + this.board[1][1] + " | " + this.board[1][2] + " ");
		System.out.println("---+---+---");
		System.out.println(" " + this.board[2][0] + " | " + this.board[2][1] + " | " + this.board[2][2] + " ");
	}
	
	private void clearBoard() {
		for(int row = 0; row < 3; row++) {
			for(int col = 0; col <3; col++) {
				this.board[row][col] = ' ';
			}
		}
	}
	
	private boolean winCondition() {
		for(int r = 0; r < 3 ; r++) {
			if(this.board[r][0]!=' ' && this.board[r][0] == this.board[r][1] && this.board[r][0] == this.board[r][2]) {
				return true;
			}
		}
		
		for(int c = 0; c < 3; c++) {
			if(this.board[0][c]!=' ' && this.board[0][c] == this.board[1][c] && this.board[0][c] == this.board[2][c]) {
				return true;
			}
		}
		
		if(this.board[1][1]!=' ' && this.board[0][0] == this.board[1][1] && this.board[0][0] == this.board[2][2]) {
			return true;
		}
		
		if(this.board[1][1]!=' ' && this.board[0][2] ==this.board[1][1] && this.board[1][1] == this.board[2][0]) {
			return true;
		}
		
		return false;
	}
	
	private boolean tieCheck() {
		for(int i = 0; i < 3; i++) {
			for(int j = 0; j < 3; j++) {
				if(this.board[i][j]==' ') {
					return false;
				}
			}
		}
		return true;
	}
}

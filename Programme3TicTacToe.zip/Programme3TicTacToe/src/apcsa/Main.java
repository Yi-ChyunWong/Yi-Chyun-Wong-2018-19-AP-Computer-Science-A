package apcsa;

public class Main{	
	public static void main(String[] args) {
		Game.init();
		Game game0 = new Game(0);
		game0.gameLoop();
		Game.close();
	}
}

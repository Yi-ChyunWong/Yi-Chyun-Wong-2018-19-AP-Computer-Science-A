package gridworld;

import java.util.ArrayList;

import info.gridworld.actor.Actor;
import info.gridworld.actor.Critter;

public class Bee extends Critter {

	@Override
	public void processActors(ArrayList<Actor> actors) {
		// Do nothing for now
	}
}

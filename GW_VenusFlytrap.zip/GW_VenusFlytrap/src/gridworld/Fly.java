package gridworld;

import java.util.ArrayList;

import info.gridworld.actor.Actor;
import info.gridworld.actor.Critter;
import info.gridworld.actor.Rock;
import info.gridworld.grid.Grid;
import info.gridworld.grid.Location;

public class Fly extends Critter {

	private boolean danger = false;

	// TODO: Add a constructor to make the fly face a random direction when created.
	// Make sure the direction is a multiple of 45 (including 0)
	
	public Fly() {
		int randNum = (int)(Math.random()*8);
		setDirection(45*randNum);
	}

	/**
	 * TODO: This particular species of fly has evolved to look very far directly in
	 * front of itself. Override getActors() to return only the actors that are one,
	 * two, or three squares directly in front of the fly.
	 */
	@Override
	public ArrayList<Actor> getActors() {
		ArrayList<Actor> a = new ArrayList<Actor>();
		ArrayList<Location> locList = new ArrayList<Location>();
		Grid<Actor> grid = getGrid();
		Location myLoc = getLocation();
		
		Location loc1 = myLoc.getAdjacentLocation(getDirection());
		Location loc2 = loc1.getAdjacentLocation(getDirection());
		Location loc3 = loc2.getAdjacentLocation(getDirection());
		
		locList.add(loc1);
		locList.add(loc2);
		locList.add(loc3);
		
		for(Location l:locList) {
			if(grid.isValid(l) && grid.get(l) != null)
				a.add(grid.get(l));
		}
		
		return a;
		
	}

	/**
	 * TODO: Override processActors() to set the instance variable danger to true if
	 * the fly sees a Venus Flytrap.
	 */
	@Override
	public void processActors(ArrayList<Actor> actors) {
		for (Actor a : actors) {
			if (a instanceof VenusFlytrap)
				this.danger = true;
		}
	}

	/**
	 * TODO: Override getMoveLocation() so that if danger is true the fly tries to
	 * fly away. For example, it could try to move one square in the opposite
	 * direction that it is facing. If that is an invalid location, it could try to
	 * move diagonally backwards or perhaps to either side. Make sure to set danger
	 * to false at the end of this method. If the fly is not in danger, the
	 * functionality of super.getMoveLocations() seems appropriate.
	 */
	@Override
	public ArrayList<Location> getMoveLocations() {
		if(!this.danger)
			return super.getMoveLocations();
		
		ArrayList<Location> locList1 = new ArrayList<Location>();
		ArrayList<Location> locList2 = new ArrayList<Location>();
		ArrayList<Location> locList3 = new ArrayList<Location>();
		Grid<Actor> grid = getGrid();
		Location myLoc = getLocation();
		int oppDir = (getDirection()+180) % 360;
		int leftDir = ((getDirection()-90)+360) % 360;
		int rightDir = (getDirection()+90) % 360;
		Location back = myLoc.getAdjacentLocation(oppDir);
		Location left = myLoc.getAdjacentLocation(leftDir);
		Location right = myLoc.getAdjacentLocation(rightDir);
		Location lb = back.getAdjacentLocation(leftDir);
		Location rb = back.getAdjacentLocation(rightDir);
		
		if(grid.isValid(back) && grid.get(back) == null)
			locList1.add(back);
		if(grid.isValid(left) && grid.get(left) == null)
			locList2.add(left);
		if(grid.isValid(right) && grid.get(right) == null)
			locList2.add(right);
		if(grid.isValid(rb) && grid.get(rb) == null)
			locList3.add(rb);
		if(grid.isValid(lb) && grid.get(lb) == null)
			locList3.add(lb);
		
		this.danger = false;
		
		if(locList1.size()>0)
			return locList1;
		else if(locList3.size()>0)
			return locList3;
		else if(locList2.size()>0)
			return locList2;
		else
			return new ArrayList<Location>();
	}

	/**
	 * TODO: Override makeMove() to change the direction the fly is facing to match
	 * the direction it moved. Note that if you'd like to call super.makeMove(loc),
	 * it does not need to be the first line. Only super() has to be the first line
	 * in the constructor.
	 */
	@Override
	public void makeMove(Location loc) {
		if(loc.compareTo(getLocation()) != 0) {
			setDirection(getLocation().getDirectionToward(loc));
			moveTo(loc);
		}
	}
}

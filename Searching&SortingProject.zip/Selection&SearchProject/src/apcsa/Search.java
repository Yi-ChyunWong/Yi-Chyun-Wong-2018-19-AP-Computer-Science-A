package apcsa;

public class Search {

	public static int numComparison = 0;

	private static int compareTo(int[] arr, int target, int i) {
		numComparison++;
		if (arr[i] == target) {
			return 0;
		} else if (target > arr[i]) {
			return 1;
		} else {
			return -1;
		}	
	}

	public static int sequentialSearch(int[] arr, int target) {
		int i = 0;
		for (i = 0; i < arr.length; i++) {
			if (compareTo(arr, target, i) == 0) {
				return i;
			}
		}
		//System.out.println(numComparison);
		return -1;
	}	
	
	public static int binarySearchIterative(int[] arr, int target)
	{
		int left = 0;
		int right = arr.length-1;
		int mid = 0;
		while(left <= right) {
			mid = (right  + left)/2;
			int compareHelp = compareTo(arr,target,mid);
			if(compareHelp == 0) {
				return mid;
			} else if(compareHelp == -1) {
					right = mid - 1;
			} else {
					left = mid + 1;
			}
		}
		return -1; // TODO: For insertionSort, return mid
	}
	
	public static int binarySearchRecursive(int[] arr, int target)
	{
		return binarySearchHelper(arr, target, 0, arr.length - 1);
	}
	
	private static int binarySearchHelper(int[] arr, int target, int left, int right)
	{
		if(left>right) {
			return -1;
		}
		int mid = (left + right) / 2;
		int compareHelp = compareTo(arr,target,mid);
		if (compareHelp == -1)
		{
			return binarySearchHelper(arr, target, left, mid - 1);
		} else if (compareHelp == 1){
			return binarySearchHelper(arr, target, mid + 1, right);
		} else {
			return mid;
		}
	} 
}

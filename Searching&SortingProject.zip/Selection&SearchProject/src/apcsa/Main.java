package apcsa;

public class Main {
	public static void main(String[] args)
	{
		int[] testArr = new int[10]; //ascending
		for(int i =0;i<10;i++) {
			testArr[i] = i;
		}

		int[] testArr2 = new int[100]; //ascending
		for(int i =0;i<100;i++) {
			testArr2[i] = i;
		}
		
		int[] testArr3 = new int[1000]; //ascending
		for(int i =0;i<1000;i++) {
			testArr3[i] = i;
		}
		
		int[] testArr4 = new int[10]; //descending
		for(int i=9;i>-1;i--) {
			testArr4[9-i] = i;
		}
		
		int[] testArr5 = new int[100]; //descending
		for(int i=99;i>-1;i--) {
			testArr5[99-i] = i;
		}
		
		int[] testArr6 = new int[1000]; //descending
		for(int i=999;i>-1;i--) {
			testArr6[999-i] = i;
		}
		
		int[] testArr7 = new int[10]; //random
		for(int i =0;i<10;i++) {
			testArr7[i] = (int)(Math.random() * 10);
		}
		
		int[] testArr8 = new int[100]; //random
		for(int i =0;i<100;i++) {
			testArr8[i] = (int)(Math.random() * 100);
		}
		
		int[] testArr9 = new int[1000]; //random
		for(int i =0;i<1000;i++) {
			testArr9[i] = (int)(Math.random() * 1000);
		}

	}
}
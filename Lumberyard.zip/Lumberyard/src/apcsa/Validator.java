package apcsa;

public interface Validator {
	
	boolean choppable();

}

package apcsa;

public class DefaultMill extends LumberMill{
	
	public DefaultMill(String str) {
		super(str);
	}
	
	public void chop() {
		String str = getStr();
		int index = str.indexOf("o");

		while(index > -1 && index < str.length()-1) {
			if(!(str.substring(index+1,index+2).equals("d")) && !(str.substring(index+1,index+2).equals("o"))) {
				str=str.substring(0,index) + str.substring(index+1,index+2) + "o" + str.substring(index+2);
				index = str.indexOf("o",index+2);
			} else {
				index = str.indexOf("o",index+1);
			}
		}
		
		setStr(str);
	}
	
}

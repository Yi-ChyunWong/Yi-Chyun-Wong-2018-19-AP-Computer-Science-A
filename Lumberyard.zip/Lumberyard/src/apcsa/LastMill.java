package apcsa;
 
public class LastMill extends LumberMill implements Validator{
	
	public LastMill(String str) {
		super(str);
	}
	
	@Override
	public void woodify() {
		String str = getStr();
		int index = str.indexOf("could");
		int lastInd = index;
		
		if(index < 0)
			return;
		
		while(index != -1) {
			lastInd = index;
			index = str.indexOf("could",index+1);
		}
		
		str = str.substring(0, lastInd) + "wood" + str.substring(lastInd + 5);
		setStr(str);
	}
	
	public void chop() {
		String str = getStr();
		int spaceInd = str.indexOf(" ");
		
		//if(spaceInd < 0) 
			//return;
		
		String l = str.substring(0,spaceInd);
		
		int firstIndex = spaceInd;
		int lastIndex = spaceInd;
		
		while(spaceInd != -1) {
			lastIndex = spaceInd;
			spaceInd = str.indexOf(" ",spaceInd + 1);
		}
		
		String r = str.substring(lastIndex + 1);
		
		str = r + str.substring(firstIndex, lastIndex + 1) + l;
		setStr(str);
	}
	
	public boolean choppable() {
		String str = getStr();
		int space = str.indexOf(" ");
		
		if(space<0)
			return false;
		
		return (str.indexOf(" ", space+1) == -1);
	}
}

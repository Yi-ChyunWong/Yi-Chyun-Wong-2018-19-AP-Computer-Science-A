package apcsa;

public class FirstMill extends LumberMill implements Validator{
	
	public FirstMill(String str) {
		super(str);
	}
	
	@Override
	public void woodify() {
		String str = getStr();
		int ind = str.indexOf("could");
		
		if(ind >= 0)
			str = str.substring(0,ind) + "wood" + str.substring(ind + 5);
		
		setStr(str);
	}
	
	public void chop() {
		String str = getStr();
		String rev = "";
		
		for(int i = str.length()-1; i >= 0; i--) {
			rev += str.substring(i,i+1);
		}
		
		setStr(rev);
	}
	
	public boolean choppable() {
		return (getStr().length()>19);
	}
}

package apcsa;

public abstract class LumberMill {
	private String str;
	
	public LumberMill(String str) {
		this.str = str;
	}
	
	public abstract void chop();
	
	public void woodify() {
		int p = this.str.indexOf("plastic");
		
		while(p >= 0) {
			String l = this.str.substring(0,p);
			String r = this.str.substring(p + 7);
			this.str = l + "owod" + r;
			p = this.str.indexOf("plastic");
		}
		
		int m = this.str.indexOf("mercury");

		while(m >= 0) {
			String l = this.str.substring(0,m);
			String r = this.str.substring(m + 7);
			this.str = l + "chuck" + r;
			m = this.str.indexOf("mercury");
		}
	}
	
	public String getStr() {
		return this.str;
	}
	
	public void setStr(String str) {
		this.str = str;
	}
}
